window.onload = function(){
    var films = document.getElementsByClassName("films-list");

    for (let i = 0; i < films.length; i++) {
        const element = films[i];
        const genres  = element.getElementsByClassName("genre-list")[0];
        
        var getGenres = genres.textContent.split(",");
        genres.textContent = "";
        for(let j = 0; j<getGenres.length; j++){
            genres.insertAdjacentHTML('afterbegin',"<span class='genre-tag'>"+getGenres[j]+"</span>")
        }
    }

    var comments = document.getElementsByClassName("comment").length;
    var el = document.getElementsByClassName("comments-count")[0];
    if(comments > 0){
        el.textContent = comments;
    } else{
        el.textContent = "0";
    }
}