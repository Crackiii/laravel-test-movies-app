<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-8 row-center">
            <div class="header"> <h3>Create Movie</h3> </div>
            <form action="<?php echo e(URL::to('/films/create')); ?>" method="POST">
                <div class="row">
                    <div class="col-6">
                        <input type="text"   class="form-control" name="film_name"         placeholder="Film Name"         id="" >
                    </div>
                    <div class="col-6">
                        <input type="text"   class="form-control" name="film_re_date"      placeholder="Film release date" id="" >
                    </div>
                    <div class="col-12">
                        <textarea            class="form-control" name="film_desc"         placeholder="Film Descrption"   id="" cols="30" rows="10"></textarea>
                    </div>
                    <div class="col-6">
                        <input type="number" class="form-control" name="film_rating"       placeholder="Film rating"       id="" >
                    </div>
                    <div class="col-6">
                        <input type="number" class="form-control" name="film_tick_price"   placeholder="Film Ticket price" id="" >
                    </div>
                    <div class="col-6">
                        <input type="text"   class="form-control" name="film_country"      placeholder="Film Country"      id="" >
                    </div>
                    <div class="col-6">
                        <input type="text"   class="form-control" name="film_genre"        placeholder="Film Genre"        id="" >
                    </div>
                    <div class="col-12">
                        <input type="text"   class="form-control" name="film_photo"        placeholder="Film Photo URL"        id="" >
                    </div>
                    
                    <input type="hidden" name="_token"   id="" value="<?php echo e(csrf_token()); ?>">
                    
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">Create Movie</button>
                    </div> 
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>