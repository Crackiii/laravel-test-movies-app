<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-12 row-center">
            <div class="header"> <h3>Films</h3> </div>

            <div class="row">
                <?php foreach ($films as $film): ?>
                <div class="col-4 films-list">
                    <a href="/films/details/<?= $film->id ?>">
                        <div class="film-data">
                            <div class="film-img"> <img src="<?= $film->photo ?>" alt=""> </div>
                            <div>Film : <b> <?= $film->name ?> </b></div>
                            <div>Description : <b> <?= $film->description ?> </b>  </div>
                            <div>Release Data: <b> <?= $film->release_date ?> </b> </div>
                            <div>Rating : <b> <?= $film->rating ?> </b> </div>
                            <div>Ticket Price : <b> <?= $film->ticket_price ?> </b> </div>
                            <div>Country : <b> <?= $film->country ?> </b> </div>
                            <div>Genre : <b class="genre-list"> <?= $film->genre ?> </b> </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
            
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>