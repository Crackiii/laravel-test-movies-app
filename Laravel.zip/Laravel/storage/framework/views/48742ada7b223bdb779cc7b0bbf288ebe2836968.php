<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
    <?php foreach ($details["data"] as $film): ?>
        <div class="col-12 row-center">
            <div class="header"> <h3>Film <?= $film->name ?> details </h3> </div>

            <div class="row">
                
                <div class="col-12 films-list">
                    <div class="film-data">
                        <div class="film-img"> <img src="<?= $film->photo ?>" alt=""> </div>
                        <div>Film : <b> <?= $film->name ?> </b></div>
                        <div>Description : <b> <?= $film->description ?> </b>  </div>
                        <div>Release Data: <b> <?= $film->release_date ?> </b> </div>
                        <div>Rating : <b> <?= $film->rating ?> </b> </div>
                        <div>Ticket Price : <b> <?= $film->ticket_price ?> </b> </div>
                        <div>Country : <b> <?= $film->country ?> </b> </div>
                        <div>Genre : <b class="genre-list"> <?= $film->genre ?> </b> </div>
                    </div>
                </div>

            </div>
            
        </div>
        <?php endforeach; ?>

    </div><!--Row End-->

    <div class="row comment-row">
        <div class="col-12">
            <div class="header"> <h3>Comments (<span class="comments-count"></span>) </div>
            <div class="row">
                <div class="col-12">
                <?php if($details["comments"] != null): ?>
                    <?php $__currentLoopData = $details["comments"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row comment">
                            <div class="col-1 col-center"> <img src="http://bootdey.com/img/Content/user_1.jpg" alt=""> </div>
                            <div class="col-2 col-center"> <?php echo e($comment->name); ?> </div>
                            <div class="col-8 col-center"> <?php echo e($comment->comment_message); ?> </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </div>
                <div class="col-12">
                    <div class="row add-comment">
                        <div class="col-12">
                            <form id="comment-form" method="post">
                                <input type="text" class="form-control" name="commenter" id="" placeholder="Type Your Comment">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <button type="submit" class="btn btn-primary"> Add Comment </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div> 
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>