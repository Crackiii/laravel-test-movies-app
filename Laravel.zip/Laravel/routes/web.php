<?php



/*
|
|
|   Films Routes 
*/ 
Route::get('/', function () { return view('welcome'); });
Route::get('/films', 'FilmsController@show')->middleware('auth');
Route::get('/films/create', function(){ return view('Films/create'); })->middleware('auth');
Route::post('/films/create', 'FilmsController@store');
Route::get('/films/details/{slug}', 'FilmsController@getSingle')->name('Film Details');


/*
|
|
|   Films Comments Routes
*/ 
Route::post('/films/comments/create','FilmsController@createComment');

/*
|
|
|   User Auth Routes 
*/
Auth::routes();

