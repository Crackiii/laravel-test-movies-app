<?php

namespace App\Http\Controllers;

use App\Films;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\DB;

class FilmsController extends Controller
{
   
    /*
    |
    |
    |  User Login and Registration Controls
    |
    |
    */
    public function regUser(Request $request){
        
        $userFname    =    $request->input('user_fname');
        $userLname    =    $request->input('user_lname');
        $userEmail    =    $request->input('user_email');
        $userPass     =    Hash::make($request->input('user_pass'));

        $userReg = DB::insert("INSERT INTO `users` VALUES (?,?,?,?,?)",[null,$userFname,$userLname,$userEmail,$userPass]);
        
        if($userReg){
            return Redirect::to('/films')->with('data', $request);
        }

    }

    public function checkLogin(Request $request){
        print_r($request->input());
    }


    /*
    |
    |
    |  Movies Controls
    |
    |
    */

    public function store(Request $request)
    {
        $film_name        =     $request->input('film_name');
        $film_desc        =     $request->input('film_desc');
        $film_re_date     =     $request->input('film_re_date');
        $film_rating      =     $request->input('film_rating');
        $film_tick_price  =     $request->input('film_tick_price');
        $film_country     =     $request->input('film_country');
        $film_genre       =     $request->input('film_genre');
        $film_photo       =     $request->input('film_photo');
        
        $i = DB::insert("INSERT INTO `films` VALUES (?,?,?,?,?,?,?,?,?)",[null,$film_name,$film_desc,$film_re_date,$film_rating,$film_tick_price,$film_country,$film_genre,$film_photo]);
        
        if($i){
            return Redirect::to('/films');
        }
    
    }

    public function show(Films $films)
    {
       $f = DB::select('SELECT * FROM `films` ');  
       if(count($f) > 0){
         return view("films/films")->with('films', $f);
       }
    }

    public function getSingle($slug){
        $f = DB::select('SELECT * FROM `films` WHERE `films`.`id`=? ',[$slug]);  
       if(count($f) > 0){
         $c = $this->getComments($slug);  
         return view("films/details")->with('details', ['data'=>$f,'comments'=>$c]);
       }
    }


    /*
    |
    |
    |  Comments Controls
    |
    |
    */

    public function getComments($slug){

        $f = DB::select('SELECT * FROM `comments`, `users` WHERE `comments`.`comment_on`=? AND `users`.`id`=`comments`.`comment_by`',[$slug]);

        if(count($f)>0){
           return $f;
        } else{
            return null;
        }
    }
    

    public function createComment(Request $request){
       
        print_r($request->input());

        $currentUser = $request->input('_currentUser');
        $currentUserName = $request->input('_currentUserName');
        $comment = $request->input('commenter');
        $commentOn = $request->input('_currentPostId');

        $i = DB::insert("INSERT INTO `comments` VALUES(?,?,?,?) ",[null,$comment,$currentUser,$commentOn]);

        if($i){
            return redirect()->back();
        }
    }





}
